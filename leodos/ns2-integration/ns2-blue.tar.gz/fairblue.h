/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
 * Copyright (c) 1994 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Computer Systems
 *	Engineering Group at Lawrence Berkeley Laboratory.
 * 4. Neither the name of the University nor of the Laboratory may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

/*Ported to ns2.1b8 by  Sunil Thulasidasan, LANL; 11/05/2001 */
/*Updated on 09/011/2002*/

#ifndef ns_fairblue_h
#define ns_fairblue_h

#include <string.h>
#include "queue.h"
#include "config.h"
#include "ip.h"

#define SFQ_BINS 23
#define SFQ_LEVELS 2
#define MIN(a,b)              ((a) > (b) ? (b) : (a))
#define MAX(a,b)              ((a) > (b) ? (a) : (b))
#define PM_TH 0.98
//#define UNPENALIZE  0.10
//#define H_INTERVAL 5

struct sfqbin {
	double pmark;
	double freezetime;
	//double penalizetime;
	int pkts;
};



class FairBlue : public Queue {
  public:
	FairBlue(); 
	~FairBlue();


  protected:
	int command(int argc, const char*const* argv); 
	void enque(Packet*);
	Packet* deque();
	PacketQueue *q_;	/* underlying FIFO queue */
	int drop_front_;	/* drop-from-front (rather than from tail) */
	
	void reset();
	void plot();
	void ecn_mark(Packet* pkt); /*for ECN support */
	int drop_early();
	void reset_bins();
	void eq_update_bins();
	void dq_update_bins(hdr_ip* pkt);
	//void decrement_bins(hdr_ip* pkt, double decrement, int force);
	void decrement_bin(double decrement, int i, int j, int k);
	void increment_bins(double increment);
	void increment_bin(double increment, int i);
	int penalize();
	int pcheck();
	

	int bytes_ ;
	int dummy_;
	int setbit_;
	int mean_pktsize_;
	double decrement_;
	double increment_;
	double holdtime_;
	int algorithm_;
	double bandwidth_;
	double  pboxtime_;
	double hinterval_;
	double pboxfreeze_;
	unsigned int clearpkts_;
	//int pbox_;
	int allocation_;
	int drop_thresh_;
	unsigned int last_fudge_;

	/*state variables for current and warm up bins*/
	int cursfq_;
	int newsfq_;


	int idle_;
	double idletime_;
	double ptc_;
	struct sfqbin bins[SFQ_LEVELS][SFQ_BINS][2];
	int p_bins[SFQ_LEVELS]; /*bin values for packet currently being queued*/
	int p_wbins[SFQ_LEVELS]; /*warmup bin values*/
	int dq_bins[SFQ_LEVELS]; /*bin information of packet being dequed*/
	int pbox_count_;
	unsigned int currfudge_;
};

#endif






